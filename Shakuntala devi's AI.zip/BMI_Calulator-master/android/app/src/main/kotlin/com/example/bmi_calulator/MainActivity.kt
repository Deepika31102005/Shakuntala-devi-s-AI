package com.example.bmi_calulator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
